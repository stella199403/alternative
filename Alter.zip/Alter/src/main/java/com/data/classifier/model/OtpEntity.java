package com.data.classifier.model;

public class OtpEntity
{
    private String otp;

    public String getOtp()
    {
        return otp;
    }

    public void setOtp(String otp)
    {
        this.otp = otp;
    }
    
}
